#include "SDL.h"
#include "SDL_image.h"
#include "SDL_ttf.h"
#include <iostream>
#include <sstream>
#include "tinyxml2.h"
#include "math.h"

// this is the code form our xml lab
//run it first to see if it works - josh
using namespace std;
using namespace tinyxml2;


SDL_Texture *loadTexture(SDL_Renderer *ren, char *name);
SDL_Texture *loadText(SDL_Renderer *ren, char *name);


int main(int argc, char*argv[]){

	//srand(time(NULL));
	XMLDocument doc;
	doc.LoadFile("coin.xml");

	int EnemyInt;
	const char *eEnemyNum = doc.FirstChildElement("coin")->FirstChildElement("value")->GetText();
	istringstream(eEnemyNum) >> EnemyInt;
	SDL_Rect *Bot = new SDL_Rect[EnemyInt];
	//positions the rects
	for (int i = 0; i < EnemyInt; i++){
		int x = 100 * i ;
		int y = 300;
		Bot[i] = { x, y, 50, 50 };
	}
	bool isRunning = true;
	//bool clicked = false;

	/*bool spin1 = false;
	bool spin2 = false;
	bool spin3 = false;
	bool spin4 = false;*/

	//kill triggers
	bool *kill = new bool[EnemyInt];
	for (int i = 0; i < EnemyInt; i++){
		kill[i] = true;
	}
	/*bool kill1 = true;
	bool kill2 = true;
	bool kill3 = true;
	bool kill4 = true;
	bool kill5 = true;*/

	//
	//doc.loadFile("coin.xml");

	int SCREENWIDTH = 800;
	int	SCREENHEIGHT = 600;
	int TEXTWIDTH = 150;
	int TEXTHEIGHT = 100;
	/*double rotateImage = 0;
	double rotateImage2 = 0;
	double rotateImage3 = 0;
	double rotateImage4 = 0;*/

	SDL_Init(SDL_INIT_EVERYTHING);
	IMG_Init(IMG_INIT_PNG);
	TTF_Init();
	
	SDL_Window *win;
	SDL_Renderer *ren;
	SDL_CreateWindowAndRenderer(800, 600, NULL, &win, &ren);

	
	
	SDL_Surface *screen = SDL_GetWindowSurface(win);
	SDL_Texture *tex = loadTexture(ren, "DankLaught.png");
	SDL_Texture *tex2 = loadTexture(ren,"fortyKeks.jpg");
	SDL_Texture *tex3 = loadTexture(ren, "JJBAlaugh.png");
	SDL_Texture *tex4 = loadTexture(ren, "JohnCenaLaugh.jpg");
	//SDL_Surface *image = IMG_Load("DankLaught.png");
	//SDL_Texture *tex = SDL_CreateTextureFromSurface(ren, screen);
	//SDL_FreeSurface(screen);
	SDL_Rect rect = { 0, 0, 500, 281 };
	
	/*SDL_Texture *player1 = loadText(ren, "player one");
	SDL_Texture *player2 = loadText(ren, "player two");*/
	///*SDL_Texture *player3 = loadText(ren, "player three");
	char text [20];
	int num = 0;
	sprintf_s(text, "score: %d", num);
	
	SDL_Texture *scoreFont = loadText(ren, text);


	SDL_Rect player = { 0, 0, 100 , 100 };
	/*SDL_Rect bot1 = { 300, 200, 100, 100 };
	SDL_Rect bot2 = { 200, 600, 100, 100 };
	SDL_Rect bot3 = { 500, 500, 100, 100 };
	SDL_Rect bot4 = { 700, 400, 100, 100 };
	SDL_Rect bot5 = { 400, 300, 100, 100 };*/

	SDL_Rect textRect = { 0, (SCREENHEIGHT - TEXTHEIGHT), TEXTWIDTH, TEXTHEIGHT};

	while (isRunning){

		SDL_Event event;

		while (SDL_PollEvent(&event)){

			switch (event.type){
			case SDL_KEYDOWN:

				switch (event.key.keysym.sym){
				case SDLK_UP:

					player.y -= 10;

					break;
				case SDLK_DOWN:
					player.y += 10;
					break;
				case SDLK_LEFT:
					player.x -= 10;
					break;
				case SDLK_RIGHT:
					player.x += 10;
					break;
				}

				break;
			case SDL_MOUSEBUTTONDOWN:

				switch (event.button.button){
				case SDL_BUTTON_LEFT:
					int x, y;
					SDL_GetMouseState(&x, &y);
					rect.x = x - (rect.w / 2);
					rect.y = y - (rect.h / 2);
					//clicked = true;
					break;
				}

				break;
			}
		}

		//trigger
		for (int i = 0; i < EnemyInt; i++){
			if (kill[i] && player.x + player.w > Bot[i].x && player.x < Bot[i].x + Bot[i].w && player.y + player.h > Bot[i].y && player.y < Bot[i].y + Bot[i].h){
				kill[i] = false;
				num++;
			}
		}

		/*if (kill1 && player.x + player.w > bot1.x && player.x < bot1.x + bot1.w && player.y + player.h > bot1.y && player.y < bot1.y + bot1.h){
			kill1 = false;
			num++;
		}

		if (kill2 && player.x + player.w > bot2.x && player.x < bot2.x + bot2.w && player.y + player.h > bot2.y && player.y < bot2.y + bot2.h){
			kill2 = false;
			num++;
		}

		if (kill3 && player.x + player.w > bot3.x && player.x < bot3.x + bot3.w && player.y + player.h > bot3.y && player.y < bot3.y + bot3.h){
			kill3 = false;
			num++;
		}

		if (kill4 && player.x + player.w > bot4.x && player.x < bot4.x + bot4.w && player.y + player.h > bot4.y && player.y < bot4.y + bot4.h){
			kill4 = false;
			num++;
		}

		if (kill5 && player.x + player.w > bot5.x && player.x < bot5.x + bot5.w && player.y + player.h > bot5.y && player.y < bot5.y + bot5.h){
			kill5 = false;
			num++;
		}*/
		/*if (spin1){
			rotateImage += 0.1;
		}
		if (spin2){
			rotateImage2 += 0.1;
		}
		if (spin3){
			rotateImage3 += 0.1;
		}
		if (spin4){
			rotateImage4 += 0.1;
		}*/

		SDL_RenderClear(ren);

		//player
		/*SDL_RenderSetViewport(ren, &player);
		SDL_RenderCopyEx(ren, tex, NULL, NULL, NULL, NULL, SDL_FLIP_NONE);*/
		SDL_RenderCopy(ren, tex, NULL, &player);

		//kill check
		for (int i = 0; i < EnemyInt; i++){
			if (kill[i]){
				SDL_RenderCopy(ren, tex2, NULL, &Bot[i]);
			}
		}
		
		/*if (kill1){
			SDL_RenderCopy(ren, tex2, NULL, &bot1);
		}

		if (kill2){
			SDL_RenderCopy(ren, tex2, NULL, &bot2);
		}

		if (kill3){
			SDL_RenderCopy(ren, tex2, NULL, &bot3);
		}

		if (kill4){
			SDL_RenderCopy(ren, tex2, NULL, &bot4);
		}

		if (kill5){
			SDL_RenderCopy(ren, tex2, NULL, &bot5);

		}*/
		////(ren, tex2, NULL, NULL);
		//SDL_RenderCopy(ren, player2, NULL, &textRect);
		////SDL_RenderPresent(ren);
		//
		//SDL_RenderSetViewport(ren, &bottemView);
		//SDL_RenderCopyEx(ren, tex3, NULL, NULL, rotateImage3, NULL, SDL_FLIP_NONE);
		////SDL_RenderCopy(ren, tex3, NULL, NULL);
		//SDL_RenderCopy(ren, player3, NULL, &textRect);
		////SDL_RenderPresent(ren);
		//
		//SDL_RenderSetViewport(ren, &bottemViewRight);
		//SDL_RenderCopyEx(ren, tex4, NULL, NULL, rotateImage4, NULL, SDL_FLIP_NONE);
		////SDL_RenderCopy(ren, tex4, NULL, NULL);
		////SDL_RenderPresent(ren);
		//SDL_RenderCopy(ren, player4, NULL, &textRect);
		//
		//
		////SDL_RenderClear(ren);
		////SDL_RenderCopy(ren, tex, NULL, &rect);
		SDL_RenderCopy(ren, scoreFont, NULL, &textRect);


		SDL_RenderPresent(ren);
		SDL_DestroyTexture(scoreFont);

		
		sprintf_s(text, "score: %d", num);
		scoreFont = loadText(ren, text);
	};
	//SDL_DestroyTexture(scoreFont);
	

	SDL_DestroyTexture(tex);
	SDL_DestroyTexture(tex2);
	/*SDL_DestroyTexture(tex3);
	SDL_DestroyTexture(tex4);*/

	SDL_FreeSurface(screen);

	SDL_DestroyRenderer(ren);
	SDL_DestroyWindow(win);

	//SDL_DestroyTexture(player1);
	//SDL_DestroyTexture(player2);
	//SDL_DestroyTexture(player3);
	//SDL_DestroyTexture(player4);

	TTF_Quit();
	IMG_Quit();
	SDL_Quit();
	return 0;
}

SDL_Texture *loadTexture(SDL_Renderer *ren, char *name){
	SDL_Surface *image = IMG_Load(name);
	SDL_Texture *texture = SDL_CreateTextureFromSurface(ren, image);
	SDL_FreeSurface(image);
	return texture;
}

SDL_Texture *loadText(SDL_Renderer *ren, char *name){
	SDL_Color color = { 255, 255, 255 };
	TTF_Font *font = TTF_OpenFont("OpenSans-Bold.ttf", 24);

	SDL_Surface *textS = TTF_RenderText_Solid(font, name, color);
	SDL_Texture *textT = SDL_CreateTextureFromSurface(ren, textS);
	SDL_FreeSurface(textS);
	TTF_CloseFont(font);
	return textT;
}